module.exports = {
    'category': '',
    'ladder-info': '',
    'commands': '641330459938390016',
    'standard-1v1': '641330047717736524',
    'standard-2v2': '',
    'rank-x-1v1': '',
    'rank-x-2v2': '641330019318235136'
}

// module.exports = {
//     'category': '641202373062033429',
//     'ladder-info': '641211165363535882',
//     'commands': '641211099668152331',
//     'standard-1v1': '641202453752053761',
//     'standard-2v2': '641202480901783552',
//     'rank-x-1v1': '641202633326985216',
//     'rank-x-2v2': '641202955592138774'
// }